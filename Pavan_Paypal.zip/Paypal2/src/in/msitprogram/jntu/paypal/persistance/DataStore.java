package in.msitprogram.jntu.paypal.persistance;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;
import java.*;

import in.msitprogram.jntu.paypal.accounts.PPAccount;
import in.msitprogram.jntu.paypal.accounts.PPRestrictedAccount;

public class DataStore
{
	
	public static PPAccount lookupAccount(String email) throws IOException, ClassNotFoundException
	{
		PPAccount account = null; //initialize it after reading from file
		// write code to open the files, read
		File f = new File("Paypal.txt");
		if(f.exists())
		{
			FileInputStream fin = new FileInputStream(f);
			ObjectInputStream oin = new ObjectInputStream(fin);
			Vector<PPAccount> v = (Vector<PPAccount>)oin.readObject();
			for(int i=0;i<v.size();i++)
			{
				account = v.get(i);
				if(account.getEmail().equals(email))
				{
					return account;
				}
			}
		}
		
			
		return null;
	}
	
	public static void writeAccount(PPAccount account) throws IOException, ClassNotFoundException
	{
		PPAccount account1;
		Vector<PPAccount> v = new Vector<PPAccount>();
		//File f = new File("Paypal.txt");
		File f = new File("Paypal.txt");
		if(f.exists())
		{
			FileInputStream fin = new FileInputStream(f);
			ObjectInputStream oin = new ObjectInputStream(fin);
			 v = (Vector<PPAccount>)oin.readObject();
			for(int i=0;i<v.size();i++)
			{
				account1 = v.get(i);
				if(account1.getEmail().equals(account.getEmail()))
				{
					v.remove(account1);
					break;
				}
			}
			FileOutputStream fout = new FileOutputStream(f);
			ObjectOutputStream oos = new ObjectOutputStream(fout);
			v.addElement(account);
			oos.writeObject(v);
		}
		else
		{
			FileOutputStream fout = new FileOutputStream(f);
			ObjectOutputStream oos = new ObjectOutputStream(fout);
			v.addElement(account);
			oos.writeObject(v);
		}
		
	}
	
}
