package in.msitprogram.jntu.paypal.console;

import java.io.IOException;
import java.util.Scanner;

import in.msitprogram.jntu.paypal.accounts.PPAccount;
import in.msitprogram.jntu.paypal.accounts.PPBusinessAccount;
import in.msitprogram.jntu.paypal.accounts.PPRestrictedAccount;
import in.msitprogram.jntu.paypal.accounts.Profile;
import in.msitprogram.jntu.paypal.persistance.DataStore;
import in.msitprogram.jntu.paypal.utils.PPToolkit;

public class PPNewAccountScreen {
	Profile profile;
	PPAccount account;
	PPRestrictedAccount account1;
	String email;
	Scanner scan;
	
	public PPNewAccountScreen(String email) {
		profile = new Profile();
		scan = new Scanner(System.in);
		this.email = email;
	}

	public void show() throws IOException, ClassNotFoundException {
		//check if the account with the given email address exists 
		
		//if not create the user profile
		
		//show the account types
		
		//based on the given account type selected create the account object
		
		try
		{
		account = DataStore.lookupAccount(email);
		}
		catch(Exception e)
		{
		}
		finally
		{
		if(account!=null)
		{
			System.out.println("Your account already exsisted");
			return;
		}
		else
		{
			profile = createProfile();
			Scanner input = new Scanner(System.in);
			System.out.println("\n1.Business Account.\n2.Student Account.\n3.Personal Account.");
			int n1 = input.nextInt();
			switch(n1)
			{
			case 1:createBusinessAccount();
			break;
			case 2:createStudentAccount();
			break;
			case 3: createPersonalAccount();
			break;
			default:
				break;
			}
		}
		}
	}

	private Profile createProfile() {
		// use this for creating the profile
		Scanner input = new Scanner(System.in);
		System.out.println("Enter name,address and phone");
		profile = new Profile(input.next(),input.next(),input.next());
		return profile;
	}

	private void createBusinessAccount() throws IOException {
		//use this for creating the business account
	}

	private void createStudentAccount() throws IOException, ClassNotFoundException {
		//use this for creating the student account
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter parent Email");
				
		String parentemail=input.next();
				
		account =DataStore.lookupAccount(parentemail);
				
		if(account==null)
				
		{
					
		System.out.println("Invalid parent Email");
				
		}
				
		else
				
		{
					
		account1=new PPRestrictedAccount(profile,email);
		account1.setParentEmail(account.getEmail());
		account1.setWithdrawLimit(5000);
		account1.setActivated(false);
		account1.addFunds(1000);
		account=account1;
		completeAccountCreation();
					
	}
	}

	/*
	 * this method create the personal account, saves it to the file system
	 * and redirects the users to the next screen
	 */
	private void createPersonalAccount() throws IOException, ClassNotFoundException {
		//use this for creating the personal account
		account=new PPAccount(profile,email);
		account.setActivated(false);
		boolean t = account.addFunds(1000);
		if(t==true)
		{
			System.out.println("Your amount is successfully credited");
		}
		completeAccountCreation();
	}
	
	private void completeAccountCreation() throws IOException, ClassNotFoundException{
		//generate activation code and set it to account
		
		//send activation code to the phone
		
		//ask & redirect the user to the activation screen or the main menu
		Scanner input = new Scanner(System.in);
		String s = PPToolkit.generateActivationCode();
		account.setActivationCode(s);
		DataStore.writeAccount(account);
		System.out.println("Your Activation Code is "+s);
		System.out.println("Press 1.Activation 2.MainMenu");
		int n = input.nextInt();
		switch(n)
		{
		case 1:PPAccountActivationScreen PPAAS = new PPAccountActivationScreen();
		       PPAAS.show();
		       break;
		case 2: MainMenu MM = new MainMenu();
				MM.show();
				break;
		}
		
		
	}

}
