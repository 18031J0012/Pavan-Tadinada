# -*- coding: utf-8 -*-

import psycopg2

conn = psycopg2.connect("dbname=tickers user=postgres password=system")
cur = conn.cursor()
cur.execute("CREATE TABLE statistics(sno serial, stat_ticker varchar PRIMARY KEY, marketcap varchar, enterprise_value varchar, return_on_assets varchar, total_cash varchar, operating_cash_flow varchar, levered_free_cash_flow varchar, toal_debt varchar, current_ratio varchar, gross_profit varchar, proffit_margin varchar);")
print("Executed")
cur.execute("CREATE TABLE profiles(prof_ticker varchar PRIMARY KEY, name varchar, Address varchar, phonenum varchar, website varchar, sector varchar, industry varchar, full_time varchar, bus_summ varchar);")
print("Executed")
cur.execute("CREATE TABLE finances(Fin_ticker varchar PRIMARY KEY, total_Revenue varchar, cost_of_revenue varchar, income_before_tax varchar, net_income varchar);")
print("Executed")
conn.commit()
print("Committed")
cur.close()
print("cursor connection closed")
conn.close()
print("Operation Successful")

