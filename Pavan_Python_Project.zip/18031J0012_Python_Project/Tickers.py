import os
import requests
import csv
from bs4 import BeautifulSoup
c=0
name=[]
url="https://finance.yahoo.com/"
page = requests.get('https://finance.yahoo.com/trending-tickers')
soup = BeautifulSoup(page.text, 'html.parser')
Tickers =soup.find_all('a',{"class":"Fw(b)"})

for i in Tickers:
    if c>=6:
        break
    else:
        name.append(i.text)
        c+=1
print(name)
i=0
for j in name:
    Dir="Ticker/"+j
    try:
        os.mkdir(Dir)
        ptint("File Created")
    except:
        print("created")

    #profile
    s=url+"quote/"+j+"/profile?p="+j
    page1 = requests.get(s)
    text=BeautifulSoup(page1.text,"html.parser")
    f=open(Dir+"/profile.htm",'w')
    f.write(str(text.encode("utf-8")))
    f.close
    
    #Finance
    s=url+"quote/"+j+"/financials?p="+j
    page1 = requests.get(s)
    text=BeautifulSoup(page1.text,"html.parser")
    f=open(Dir+"/Financial.htm",'w')
    f.write(str(text.encode("utf-8")))
    f.close
    
    #Statistics
    s=url+"quote/"+j+"/key-statistics?p="+j
    page1 = requests.get(s)
    text=BeautifulSoup(page1.text,"html.parser")
    f=open(Dir+"/Statistics.htm",'w')
    f.write(str(text.encode("utf-8")))
    f.close

    #Summary
    s=url+"quote/"+j+"?p="+j
    page1 = requests.get(s)
    text=BeautifulSoup(page1.text,"html.parser")
    f=open(Dir+"/Summary.htm",'w')
    f.write(str(text.encode("utf-8")))
    f.close
