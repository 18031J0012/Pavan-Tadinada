Credentials:
database = tickers
user = postgres  
password = system 
host = 127.0.0.1
port = 5432