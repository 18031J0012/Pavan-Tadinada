from bs4 import BeautifulSoup
import os
import psycopg2
path="Ticker"
arr=os.listdir(path)
increment=0
for ar in arr:
	files=os.listdir(path+"/"+ar)
	print(files)
	print(ar)
	for f in files	:	
		# collecting data for finance and pushing it to the postgresql database and inserting data into finance table
		if "Financial" in f:
				conn = psycopg2.connect(database="tickers", user="postgres", password="system", host="127.0.0.1", port="5432")
				fin=[ar]
				count=0
				count1=0
				count2=0
				soup = BeautifulSoup(open("F:\\Python\\Python\\Python Project\\"+path+"\\"+ar+"\\"+f), "html.parser")
				containers3=soup.find_all('tr',{'class':'Bdbw(1px) Bdbc($c-fuji-grey-c) Bdbs(s) H(36px)'})
				for i in containers3:
					
					s=i.find_all('td')
					for j in s:
						sr=j.text
						if(ord(sr[0])>64):
							sp=j.text
							if(sp=='Net Income'):
								count+=1
						if(sp=='Revenue' or sp=='Total Revenue' or sp=='Cost of Revenue' or sp=='Income Before Tax' or (sp=='Net Income' and count==2)):
							count1+=1
							if(sp=='Revenue'):
								count2+=1
								print(count2)
							if(count2==5):
								if(count1==7 or count1==12 or count1==17 or count1==22):
									fin.append((j.text).replace(',',''))
									#print(j.text,count1,ar)
							else:
								if(count1==6 or count1==10 or count1==14 or count1==18):
									fin.append((j.text).replace(',',''))
				try:					#print(j.text,count1,ar)
					print(fin)
					cur = conn.cursor()
					print("asdfg",fin[0])
					cur.execute("INSERT INTO finances (Fin_ticker, total_Revenue, cost_of_revenue,income_before_tax,net_income) \
						 VALUES (%s,%s,%s,%s,%s)",(fin));
					conn.commit()
					print("Records created successfully");
					conn.close()
				except:
					print("already inserted")
		#collecting data for profiles and inserting the data to the postgresql database and inserting the data into profile table
		if "profile" in f:
				try:
					fin=[ar]
					conn = psycopg2.connect(database="tickers", user="postgres", password="system", host="127.0.0.1", port="5432")
					soup1=BeautifulSoup(open("F:\\Python\\Python\\Python Project\\"+path+"\\"+ar+"\\"+f),"html.parser")
					containers1=soup1.find(class_='asset-profile-container')
					containers2=soup1.find(class_='W(100%)')
					items1=containers1.find('h3')
					itemsadd=containers1.find('p')
					itemssecInd=soup1.find_all('span',{'class':'Fw(600)'})
					#print(items1.text+"ad"+str)
					fin.append(items1.text)
					str3=itemsadd.text
					d=str3.find('http')
					fin.append(str3[:d])
					
					#print(str3[:d]+str)
					phone=str3[:d]
					num=phone[-12:]
					num=num.replace('-','')
					if(num.isnumeric()):
						fin.append(num.replace('-',''))
					else:
						fin.append("0")	
					fin.append(str3[d:])
					#print(str3[d:]+str)
					for i in itemssecInd:
						#print(i.text+"addd"+str)
						fin.append((i.text).replace(',',''))
					fin.append("null")
					if(fin[7]==""):
						fin[7]=0
					try:
						print(fin)
						cur = conn.cursor()
						cur.execute("INSERT INTO profiles (prof_ticker,name,Address,phonenum,website,sector,industry,full_time,bus_summ) \
						 VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)",(fin));
						conn.commit()
						print("Records created successfully");
						conn.close()
					except:
						print("sas")
				except:				
					print("unable to create profile right now, have you checked your code properly?")
		#collecting data for statistics and inserting data to the postgres database and inserting into statistics table
		if "Statistics" in f:
				try:
					increment+=1
					conn = psycopg2.connect(database="tickers", user="postgres", password="system", host="127.0.0.1", port="5432")
					listToFindData1 = ["Market Cap (intraday) 5","Enterprise Value 3","Return on Assets (ttm)","Total Cash (mrq)","Operating Cash Flow (ttm)","Levered Free Cash Flow (ttm)","Total Debt (mrq)","Current Ratio (mrq)","Gross Profit (ttm)","Profit Margin "]
					listData1 = []
					soup=BeautifulSoup(open("F:\\Python\\Python\\Python Project\\"+path+"\\"+ar+"\\"+f),"html.parser")
					table = soup.find(class_='Fl(start) W(50%) smartphone_W(100%)')
	#tables = table.find_all('table')
					lines = [th.get_text() for th in table.find('tr').find_all('th')]
					for rows in table.find_all('tr')[0:]:
						data = [td.get_text() for td in rows.find_all('td')]
						#print(data[0])
						if listToFindData1.__contains__(data[0]):
							listData1.append(data[1])
							#print(data[1])
					#print("to Data Base ====",listData1)
					listData2=[increment,ar]
					for a in listData1:
						if(a[-1]=='B'):
							a=(a.replace('B',''))
							a=float(a)*(10**9)
							listData2.append(a)
						elif(a[-1]=='M'):
							a=(a.replace('M',''))
							a=float(a)*(10**6)
							listData2.append(a)
						elif(a[-1]=='%'):
							a=(a.replace('%',''))
							listData2.append(a)
						elif(a[-1]=='T'):
							a=(a.replace('T',''))
							a=float(a)*(10**12)
							listData2.append(a)
						elif(a=='N/A'):
							a=0
							listData2.append(a)
						else:
							listData2.append(a)
					print(listData2)
					try:
						cur = conn.cursor()
						cur.execute("INSERT INTO statistics (sno, stat_ticker , marketcap, enterprise_value, return_on_assets , total_cash, operating_cash_flow, levered_free_cash_flow , toal_debt, current_ratio, gross_profit, proffit_margin) \
							 VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(listData2));
						conn.commit()
						print("Records created successfully for statistics");
						conn.close()
					except:
						print("exists")
				except:
					print("unable to create stats right now, have you checked your code properly?")
