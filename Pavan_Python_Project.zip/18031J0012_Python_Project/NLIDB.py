import psycopg2
f = open("F:\\Python\\Python\\Python Project\\Stopwords.txt")
list=[]
for i in f:
    i = i.replace('"','')
    list.append(i.strip())
q=input("Enter your question: ")
arr=[]
q1=q.split(" ")
for j in q1:
    if j not in list:
        arr.append(j)
print (arr)

# Creating query
def query_generation(arr,dict,com):
    From = "com"
    att = ""
    attri = ""
    na = ""
    for i in arr:
        if 'wh' in i:
            select  = "select"
            dict1 = dict.keys()
        elif i in dict1:
            att = i
            attri = dict[i]
            if dict[i] == "profiles":
                prof_ticker = "prof_ticker"
            elif dict[i] == "statistics":
                prof_ticker = "stat_ticker"
        else:
            na = i
            From = i
    return select+" "+att+" "+"from"+" "+attri+" "+"where"+" "+prof_ticker+"= '"+na+"'"
f= open("F:\\Python\\Python\\Python Project\\Tickers.txt",'r')
Com_names=[]
for i in f:
    inc=i.split("::")
    Com_names.append(inc[0].strip())
dict={"stat_ticker" :"statistics","marketcap":"statistics","enterprise_value" :"statistics","return_on_assets" : "statistics","total_cash" : "statistics","operating_cash_flow" :"statistics","levered_free_cash_flow" :"statistics","total_debt" : "statistics","current_ratio" :"statistics","gross_profit" :"statistics","profit_margin" :"statistics","prof_ticker" :"profiles","name" : "profiles","address" : "profiles","phone_num" :"profiles","website" : "profiles","sector" : "profiles","industry" :"profiles","full_time" :"profiles","fin_ticker" : "finances","total_revenue": "finances","cost_of_revenue": "finances","income_before_tax" : "finances","net_income" : "finances","a_1":"total_revenue","a_2":"total_revenue","a_3":"total_revenue","a_4":"total_revenue","a_1":"cost_of_revenue","a_2":"cost_of_revenue","a_3":"cost_of_revenue","a_4":"cost_of_revenue","a_1":"income_before_tax","a_2":"income_before_tax","a_3":"income_before_tax","a_4":"income_before_tax","a_1":"net_income","a_2":"net_income","a_3":"net_income","a_4":"net_income"}
query=query_generation(arr,dict,Com_names)
print(query)
conn = psycopg2.connect(database="tickers", user="postgres", password="system", host="127.0.0.1", port="5432")
cur=conn.cursor()
cur.execute(query)
rows=cur.fetchall()
print(rows)
conn.close()
