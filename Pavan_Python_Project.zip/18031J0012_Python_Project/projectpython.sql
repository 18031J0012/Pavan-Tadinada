--
-- PostgreSQL database dump
--

-- Dumped from database version 11.1
-- Dumped by pg_dump version 11.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: finances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.finances (
    fin_ticker character varying NOT NULL,
    total_revenue character varying,
    cost_of_revenue character varying,
    income_before_tax character varying,
    net_income character varying
);


ALTER TABLE public.finances OWNER TO postgres;

--
-- Name: profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.profiles (
    prof_ticker character varying NOT NULL,
    name character varying,
    address character varying,
    phonenum character varying,
    website character varying,
    sector character varying,
    industry character varying,
    full_time character varying,
    bus_summ character varying
);


ALTER TABLE public.profiles OWNER TO postgres;

--
-- Name: statistics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.statistics (
    sno integer NOT NULL,
    stat_ticker character varying NOT NULL,
    marketcap character varying,
    enterprise_value character varying,
    return_on_assets character varying,
    total_cash character varying,
    operating_cash_flow character varying,
    levered_free_cash_flow character varying,
    toal_debt character varying,
    current_ratio character varying,
    gross_profit character varying,
    proffit_margin character varying
);


ALTER TABLE public.statistics OWNER TO postgres;

--
-- Name: statistics_sno_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.statistics_sno_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.statistics_sno_seq OWNER TO postgres;

--
-- Name: statistics_sno_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.statistics_sno_seq OWNED BY public.statistics.sno;


--
-- Name: statistics sno; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statistics ALTER COLUMN sno SET DEFAULT nextval('public.statistics_sno_seq'::regclass);


--
-- Data for Name: finances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.finances (fin_ticker, total_revenue, cost_of_revenue, income_before_tax, net_income) FROM stdin;
AMRS	143445	119669	-72034	-72329
DIS	59434000	32726000	14729000	12598000
EA	5150000	1277000	1449000	1043000
SNAP	824949	677148	-3463408	-3445066
TSLA	-	-	-	-
APPN	176737	64597	-30246	-31007
EXPE	10059844	1756531	416764	377964
SHLDQ	16702000	12866000	-981000	-383000
SKX	4180826	2225271	384260	179190
TATAMOTORS.NS	2942425700	1682639000	134332900	89889100
TTM	2942425700	1682639000	134332900	89889100
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.profiles (prof_ticker, name, address, phonenum, website, sector, industry, full_time, bus_summ) FROM stdin;
AMRS	Amyris, Inc.	5885 Hollis StreetSuite 100Emeryville, CA 94608United States510-450-0761	5104500761	http://www.amyris.com	Basic Materials	Specialty Chemicals	414	null
DIS	The Walt Disney Company	500 South Buena Vista StreetBurbank, CA 91521United States818-560-1000	8185601000	http://www.thewaltdisneycompany.com	Consumer Cyclical	Media - Diversified	201000	null
EA	Electronic Arts Inc.	209 Redwood Shores ParkwayRedwood City, CA 94065United States650-628-1500	6506281500	http://www.ea.com	Technology	Electronic Gaming & Multimedia	9300	null
SNAP	Snap Inc.	2772 Donald Douglas Loop NorthSanta Monica, CA 90405United States310-399-3339	3103993339	http://www.snap.com	Technology	Internet Content & Information	3069	null
TSLA	Tesla, Inc.	3500 Deer Creek RoadPalo Alto, CA 94304United States650-681-5000	6506815000	http://www.tesla.com	Consumer Cyclical	Auto Manufacturers	0	null
APPN	Appian Corporation	11955 Democracy DriveSuite 1700Reston, VA 20190United States703-442-8844	7034428844	http://www.appian.com	Technology	Software - Infrastructure	2000	null
EXPE	Expedia Group, Inc.	333 108th Avenue NEBellevue, WA 98004United States425-679-7200	4256797200	http://www.expediagroup.com	Consumer Cyclical	Leisure	22615	null
SHLDQ	Sears Holdings Corporation	3333 Beverly RoadHoffman Estates, IL 60179United States847-286-2500	8472862500	http://www.searsholdings.com	Consumer Cyclical	Department Stores	89000	null
SKX	Skechers U.S.A., Inc.	228 Manhattan Beach BoulevardManhattan Beach, CA 90266United States310-318-3100	3103183100	http://www.skechers.com	Consumer Cyclical	Footwear & Accessories	4500	null
TATAMOTORS.NS	Tata Motors Limited	Ahura Centre4th Floor 82 Mahakali Caves Road MIDC, Andheri EastMumbai 400093India91 22 6240 7101	0	http://www.tatamotors.com	Consumer Cyclical	Auto Manufacturers	81090	null
TTM	Tata Motors Limited	Ahura Centre4th Floor 82 Mahakali Caves Road MIDC, Andheri EastMumbai 400093India91 22 6240 7101	0	http://www.tatamotors.com	Consumer Cyclical	Auto Manufacturers	81090	null
\.


--
-- Data for Name: statistics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.statistics (sno, stat_ticker, marketcap, enterprise_value, return_on_assets, total_cash, operating_cash_flow, levered_free_cash_flow, toal_debt, current_ratio, gross_profit, proffit_margin) FROM stdin;
1	AMRS	418600000.0	382400000.0	-112.96	-17.05	23780000.0	19050000.0	171120000.0	0.44	-85920000.0	-38030000.0
2	DIS	167940000000.0	187600000000.0	21.20	9.54	26710000000.0	4150000000.0000005	20870000000.0	0.94	14300000000.0	7630000000.0
3	EA	27950000000.0	24010000000.0	18.76	9.86	3870000000.0	4540000000.0	993000000.0	3.52	1460000000.0	267000000.0
4	SNAP	9120000000.0	7530000000.0	-131.39	-26.90	147800000.0	1410000000.0	0	6.04	-739950000.0	-361100000.0
5	TSLA	55190000000.0	63380000000.0	-4.55	-0.54	0	3690000000.0	11970000000.0	0.83	2100000000.0	-946340000.0
1	APPN	2180000000.0	1930000000.0	-19.54	-14.45	112140000.0	107270000.0	0	1.70	-22950000.0	-3580000.0
2	EXPE	19050000000.0	20960000000.0	4.04	2.36	8300000000.000001	3380000000.0	3730000000.0	0.70	1970000000.0	1070000000.0000001
3	SHLDQ	82470000.0	5380000000.0	-12.66	-9.00	3840000000.0	526000000.0	5840000000.0	0.77	-1060000000.0	377120000.0
4	SKX	4380000000.0	3710000000.0	4.11	8.99	1960000000.0	890050000.0	87040000.0	3.43	396640000.0	201480000.0
5	TATAMOTORS.NS	482150000000.0	1200000000000.0	0.12	1.61	1260000000000.0	355670000000.0	929230000000.0	0.92	0	0
5	TTM	7170000000.0	7740000000.0	0.12	1.61	1260000000000.0	0	0	0.92	0	0
\.


--
-- Name: statistics_sno_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.statistics_sno_seq', 1, false);


--
-- Name: finances finances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.finances
    ADD CONSTRAINT finances_pkey PRIMARY KEY (fin_ticker);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (prof_ticker);


--
-- Name: statistics statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statistics
    ADD CONSTRAINT statistics_pkey PRIMARY KEY (stat_ticker);


--
-- PostgreSQL database dump complete
--

